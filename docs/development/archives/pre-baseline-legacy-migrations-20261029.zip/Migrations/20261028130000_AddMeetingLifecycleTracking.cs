using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEXUS.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddMeetingLifecycleTracking : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "ActualEndTime",
                table: "Meetings",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ActualStartTime",
                table: "Meetings",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "AgendaItemId",
                table: "MeetingActions",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_MeetingActions_AgendaItemId",
                table: "MeetingActions",
                column: "AgendaItemId");

            migrationBuilder.AddForeignKey(
                name: "FK_MeetingActions_MeetingAgendas_AgendaItemId",
                table: "MeetingActions",
                column: "AgendaItemId",
                principalTable: "MeetingAgendas",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MeetingActions_MeetingAgendas_AgendaItemId",
                table: "MeetingActions");

            migrationBuilder.DropIndex(
                name: "IX_MeetingActions_AgendaItemId",
                table: "MeetingActions");

            migrationBuilder.DropColumn(
                name: "AgendaItemId",
                table: "MeetingActions");

            migrationBuilder.DropColumn(
                name: "ActualEndTime",
                table: "Meetings");

            migrationBuilder.DropColumn(
                name: "ActualStartTime",
                table: "Meetings");
        }
    }
}
