using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEXUS.Persistence.Migrations
{
    /// <summary>
    /// Extends the shared audit log with project scope, event source, correlation
    /// and change metadata, and adds the indexes used by the project audit trail.
    /// Deployment note: this migration is created but intentionally not applied.
    /// Apply it only after an independently verified backup and a reviewed script.
    /// </summary>
    public partial class AddProjectAuditTrail : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // SQL Server cannot index nvarchar(max) key columns. Bound the two
            // filter columns first (truncating any outlier values) so the trail
            // filters stay index-supported.
            migrationBuilder.Sql("""
                UPDATE [AuditEntries] SET [EntityType] = LEFT([EntityType], 128) WHERE LEN([EntityType]) > 128;
                UPDATE [AuditEntries] SET [Action] = LEFT([Action], 96) WHERE LEN([Action]) > 96;
                """);

            migrationBuilder.AlterColumn<string>(
                name: "EntityType",
                table: "AuditEntries",
                type: "nvarchar(128)",
                maxLength: 128,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Action",
                table: "AuditEntries",
                type: "nvarchar(96)",
                maxLength: 96,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "ChangedFields",
                table: "AuditEntries",
                type: "nvarchar(1000)",
                maxLength: 1000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CorrelationId",
                table: "AuditEntries",
                type: "nvarchar(128)",
                maxLength: 128,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Description",
                table: "AuditEntries",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "ProjectId",
                table: "AuditEntries",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Source",
                table: "AuditEntries",
                type: "nvarchar(32)",
                maxLength: 32,
                nullable: true);

            // Deterministic backfill: a project record's entity id *is* its project
            // id. No other value is inferred for historical rows.
            migrationBuilder.Sql("""
                UPDATE [AuditEntries]
                SET [ProjectId] = [EntityId]
                WHERE [ProjectId] IS NULL AND [EntityType] = N'Project';

                UPDATE [AuditEntries]
                SET [Source] = N'Unknown'
                WHERE [Source] IS NULL;
                """);

            migrationBuilder.AlterColumn<string>(
                name: "UserName",
                table: "AuditEntries",
                type: "nvarchar(256)",
                maxLength: 256,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "IpAddress",
                table: "AuditEntries",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "UserAgent",
                table: "AuditEntries",
                type: "nvarchar(512)",
                maxLength: 512,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_AuditEntries_TenantId_ProjectId_Timestamp",
                table: "AuditEntries",
                columns: new[] { "TenantId", "ProjectId", "Timestamp" });

            migrationBuilder.CreateIndex(
                name: "IX_AuditEntries_TenantId_Timestamp",
                table: "AuditEntries",
                columns: new[] { "TenantId", "Timestamp" });

            migrationBuilder.CreateIndex(
                name: "IX_AuditEntries_TenantId_EntityType_EntityId",
                table: "AuditEntries",
                columns: new[] { "TenantId", "EntityType", "EntityId" });

            migrationBuilder.CreateIndex(
                name: "IX_AuditEntries_TenantId_Action",
                table: "AuditEntries",
                columns: new[] { "TenantId", "Action" });

            migrationBuilder.CreateIndex(
                name: "IX_AuditEntries_TenantId_UserId",
                table: "AuditEntries",
                columns: new[] { "TenantId", "UserId" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_AuditEntries_TenantId_UserId",
                table: "AuditEntries");

            migrationBuilder.DropIndex(
                name: "IX_AuditEntries_TenantId_Action",
                table: "AuditEntries");

            migrationBuilder.DropIndex(
                name: "IX_AuditEntries_TenantId_EntityType_EntityId",
                table: "AuditEntries");

            migrationBuilder.DropIndex(
                name: "IX_AuditEntries_TenantId_Timestamp",
                table: "AuditEntries");

            migrationBuilder.DropIndex(
                name: "IX_AuditEntries_TenantId_ProjectId_Timestamp",
                table: "AuditEntries");

            migrationBuilder.DropColumn(name: "Source", table: "AuditEntries");
            migrationBuilder.DropColumn(name: "ProjectId", table: "AuditEntries");
            migrationBuilder.DropColumn(name: "Description", table: "AuditEntries");
            migrationBuilder.DropColumn(name: "CorrelationId", table: "AuditEntries");
            migrationBuilder.DropColumn(name: "ChangedFields", table: "AuditEntries");

            migrationBuilder.AlterColumn<string>(
                name: "UserAgent",
                table: "AuditEntries",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(512)",
                oldMaxLength: 512,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "IpAddress",
                table: "AuditEntries",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(64)",
                oldMaxLength: 64,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "UserName",
                table: "AuditEntries",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(256)",
                oldMaxLength: 256,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Action",
                table: "AuditEntries",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(96)",
                oldMaxLength: 96);

            migrationBuilder.AlterColumn<string>(
                name: "EntityType",
                table: "AuditEntries",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(128)",
                oldMaxLength: 128);
        }
    }
}
