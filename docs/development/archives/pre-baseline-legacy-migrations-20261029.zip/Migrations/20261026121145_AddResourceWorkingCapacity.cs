﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEXUS.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddResourceWorkingCapacity : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "HoursPerDay",
                table: "Resources",
                type: "decimal(10,2)",
                precision: 10,
                scale: 2,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "HoursPerWeek",
                table: "Resources",
                type: "decimal(10,2)",
                precision: 10,
                scale: 2,
                nullable: true);

            migrationBuilder.AddCheckConstraint(
                name: "CK_Resources_HoursPerDay_Range",
                table: "Resources",
                sql: "[HoursPerDay] IS NULL OR ([HoursPerDay] > 0 AND [HoursPerDay] <= 24)");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Resources_HoursPerWeek_Range",
                table: "Resources",
                sql: "[HoursPerWeek] IS NULL OR ([HoursPerWeek] > 0 AND [HoursPerWeek] <= 168)");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CK_Resources_HoursPerDay_Range",
                table: "Resources");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Resources_HoursPerWeek_Range",
                table: "Resources");

            migrationBuilder.DropColumn(
                name: "HoursPerDay",
                table: "Resources");

            migrationBuilder.DropColumn(
                name: "HoursPerWeek",
                table: "Resources");
        }
    }
}
