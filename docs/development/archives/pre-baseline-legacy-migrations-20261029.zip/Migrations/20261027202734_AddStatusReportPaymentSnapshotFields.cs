﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEXUS.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddStatusReportPaymentSnapshotFields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "ActualPaidSnapshot",
                table: "ProjectStatusReports",
                type: "decimal(19,4)",
                precision: 19,
                scale: 4,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "OutstandingPlannedPaymentsSnapshot",
                table: "ProjectStatusReports",
                type: "decimal(19,4)",
                precision: 19,
                scale: 4,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "PaymentsDueWithinPeriodSnapshot",
                table: "ProjectStatusReports",
                type: "decimal(19,4)",
                precision: 19,
                scale: 4,
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "RemainingUnpaidAtPeriodEndSnapshot",
                table: "ProjectStatusReports",
                type: "decimal(19,4)",
                precision: 19,
                scale: 4,
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ActualPaidSnapshot",
                table: "ProjectStatusReports");

            migrationBuilder.DropColumn(
                name: "OutstandingPlannedPaymentsSnapshot",
                table: "ProjectStatusReports");

            migrationBuilder.DropColumn(
                name: "PaymentsDueWithinPeriodSnapshot",
                table: "ProjectStatusReports");

            migrationBuilder.DropColumn(
                name: "RemainingUnpaidAtPeriodEndSnapshot",
                table: "ProjectStatusReports");
        }
    }
}
