using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEXUS.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class SeparateMeetingInvitationAndAttendanceStatuses : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "InvitationResponseStatus",
                table: "MeetingParticipants",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: true);

            migrationBuilder.Sql("""
                UPDATE [MeetingParticipants]
                SET [InvitationResponseStatus] = COALESCE([InvitationResponseStatus], CASE LOWER(LTRIM(RTRIM([AttendanceStatus])))
                        WHEN N'pending' THEN N'Pending'
                        WHEN N'accepted' THEN N'Accepted'
                        WHEN N'declined' THEN N'Declined'
                        WHEN N'tentative' THEN N'Tentative'
                        ELSE NULL
                    END),
                    [AttendanceStatus] = CASE
                        WHEN LOWER(LTRIM(RTRIM([AttendanceStatus]))) IN (N'pending', N'accepted', N'declined', N'tentative') THEN NULL
                        WHEN LOWER(LTRIM(RTRIM([AttendanceStatus]))) = N'attended' THEN N'Present'
                        ELSE [AttendanceStatus]
                    END
                WHERE [AttendanceStatus] IS NOT NULL;
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("""
                UPDATE [MeetingParticipants]
                SET [AttendanceStatus] = COALESCE([AttendanceStatus], [InvitationResponseStatus])
                WHERE [InvitationResponseStatus] IS NOT NULL;
                """);

            migrationBuilder.DropColumn(
                name: "InvitationResponseStatus",
                table: "MeetingParticipants");
        }
    }
}
