using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEXUS.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddMeetingActionWorkItemLink : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "WorkItemId",
                table: "MeetingActions",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_MeetingActions_WorkItemId",
                table: "MeetingActions",
                column: "WorkItemId");

            migrationBuilder.AddForeignKey(
                name: "FK_MeetingActions_WorkItems_WorkItemId",
                table: "MeetingActions",
                column: "WorkItemId",
                principalTable: "WorkItems",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MeetingActions_WorkItems_WorkItemId",
                table: "MeetingActions");

            migrationBuilder.DropIndex(
                name: "IX_MeetingActions_WorkItemId",
                table: "MeetingActions");

            migrationBuilder.DropColumn(
                name: "WorkItemId",
                table: "MeetingActions");
        }
    }
}
