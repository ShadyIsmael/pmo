using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using NEXUS.Persistence;

#nullable disable

namespace NEXUS.Persistence.Migrations;

[DbContext(typeof(AppDbContext))]
[Migration("20261029153000_AddProjectFinanceApprovalMode")]
public sealed class AddProjectFinanceApprovalMode : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<string>(
            name: "FinanceApprovalMode",
            table: "Projects",
            type: "nvarchar(24)",
            maxLength: 24,
            nullable: true);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        // Keep persisted configuration if a later release rolls back the feature.
    }
}
